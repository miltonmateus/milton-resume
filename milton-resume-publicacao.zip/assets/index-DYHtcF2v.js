(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e={personal:{fullName:`Milton Mateus Alves Teixeira Filho`,professionalTitle:`Software Engineer <span>.</span> Full Stack Developer`,email:`miltonmatews@gmail.com`,phone:`+55 51 98138-4112`,location:`Porto Alegre - RS`,linkedin:`https://www.linkedin.com/in/milton-teixeira-89147598`,profileImage:`/Milton.jpg`},summary:{title:`Sobre mim`,paragraphs:[`Desenvolvedor Full Stack com mais de oito anos de experiência no desenvolvimento de aplicações web, APIs e sistemas corporativos.`,`Atuação em projetos dos setores financeiro, judiciário e de recursos humanos, trabalhando tanto no backend quanto no frontend.`,`Experiência com Java, TypeScript, Node.js, NestJS, C#, Angular, React, SvelteKit e MongoDB.`]},skills:[{title:`Linguagens`,skills:[`Java`,`TypeScript`,`JavaScript`,`C#`,`Python`,`PHP`,`SQL`]},{title:`Backend`,skills:[`Node.js`,`NestJS`,`ASP.NET Core`,`REST APIs`,`Swagger / OpenAPI`]},{title:`Frontend`,skills:[`Angular`,`React`,`Next.js`,`SvelteKit`,`HTML5`,`CSS3`]},{title:`Banco de dados`,skills:[`MongoDB`,`Oracle`]},{title:`Ferramentas`,skills:[`Git`,`Azure DevOps`,`Docker`,`Linux`,`Postman`]}],experience:[{company:`Villela Brasil Bank`,role:`Desenvolvedor Full Stack`,startDate:`2026`,endDate:`Atual`,location:`Porto Alegre - RS`,description:[`Desenvolvimento e manutenção de APIs REST para sistemas do setor financeiro.`,`Desenvolvimento de aplicações web completas, atuando no backend e no frontend.`,`Implementação de novas funcionalidades, integrações e correção de incidentes em produção.`]},{company:`South System`,role:`Desenvolvedor Full Stack`,startDate:`2016`,endDate:`2019`,location:`Porto Alegre - RS`,description:[`Desenvolvimento frontend utilizando Angular.`,`Desenvolvimento backend com Node.js.`,`Mineração e processamento de dados com Python e Beautiful Soup.`,`Refatoração de aplicações internas e participação em projetos de reconhecimento de imagens.`]},{company:`Tribunal de Justiça do Rio Grande do Sul`,role:`Técnico de Banco de Dados`,startDate:`2013`,endDate:`2015`,location:`Porto Alegre - RS`,description:[`Validação de dados provenientes de sistemas externos.`,`Administração de acessos por meio do Microsoft Active Directory.`,`Suporte às bases Oracle utilizadas pelo órgão.`]}],education:[{institution:`Centro Universitário Ritter dos Reis`,course:`Tecnólogo em Desenvolvimento de Jogos Digitais`,startDate:`2026`,status:`Em andamento — 2º semestre`},{institution:`Pontifícia Universidade Católica do Rio Grande do Sul`,course:`Bacharelado em Ciência da Computação`,startDate:`2013`,endDate:`2014`,status:`Não concluído`}],languages:[{name:`Português`,level:`Nativo`},{name:`Inglês`,level:`Fluente`}]};function t(e){return`
    <header class="profile">
      <div class="photo-ring"><img class="profile-image" src="${e.profileImage}" alt="Foto de ${e.fullName}" /></div>
      <h1>${e.fullName}</h1>
      <p class="professional-title">${e.professionalTitle}</p>
      <div class="title-rule"></div>
      <section class="contact sidebar-section">
        <h2><span class="section-icon">◎</span> Contato</h2>
        <ul>
          <li><span aria-hidden="true">✉</span><a href="mailto:${e.email}">${e.email}</a></li>
          <li><span aria-hidden="true">☎</span><a href="tel:${e.phone}">${e.phone}</a></li>
          <li><span aria-hidden="true">●</span><span>${e.location}</span></li>
          <li><span aria-hidden="true">in</span><a href="${e.linkedin}" target="_blank" rel="noreferrer">linkedin.com/in/milton-teixeira</a></li>
        </ul>
      </section>
    </header>
  `}function n(e){return`
    <section class="summary content-section">
      <h2><span class="section-icon">●</span>${e.title}</h2>
      ${e.paragraphs.map(e=>`<p>${e}</p>`).join(``)}
    </section>
  `}function r(e){return`
    <section class="experience content-section">
      <h2><span class="section-icon">▣</span>Experiência profissional</h2>

      <div class="timeline">${e.map(e=>`
            <article class="experience-item">
              <div class="experience-heading">
                <div><h3>${e.company}</h3><p class="role">${e.role}</p></div>
                <div class="meta"><p>${e.startDate} — ${e.endDate}</p><p>${e.location}</p></div>
              </div>

              <ul>
                ${e.description.map(e=>`<li>${e}</li>`).join(``)}
              </ul>
            </article>
          `).join(``)}</div>
    </section>
  `}function i(e){return`
    <section class="skills sidebar-section">
      <h2><span class="section-icon">&lt;/&gt;</span> Competências</h2>

      ${e.map(e=>`
            <article class="skill-group">
              <h3>${e.title}</h3>

              <ul>
                ${e.skills.map(e=>`<li>${e}</li>`).join(``)}
              </ul>
            </article>
          `).join(``)}
    </section>
  `}function a(e){return`
    <section class="education content-section">
      <h2><span class="section-icon">◆</span>Formação acadêmica</h2>

      <div class="education-grid">${e.map(e=>`
            <article class="education-item">
              <h3>${e.institution}</h3>
              <p>${e.course}</p>
              <p>
                ${e.startDate}
                ${e.endDate?` — ${e.endDate}`:``}
              </p>
              <p>${e.status}</p>
            </article>
          `).join(``)}</div>
    </section>
  `}function o(e){return`
    <section class="languages sidebar-section">
      <h2><span class="section-icon">◎</span> Idiomas</h2>

      <ul>
        ${e.map(e=>`
              <li class="language-item">
                <div><strong>${e.name}</strong><span>${e.level}</span></div>
                <span class="language-bar"><i style="width: ${e.level===`Nativo`?`100`:`92`}%"></i></span>
              </li>
            `).join(``)}
      </ul>
    </section>
  `}function s(e){return`
    <main class="resume">
      <aside class="sidebar">
        ${t(e.personal)}
        ${i(e.skills)}
        ${o(e.languages)}
      </aside>
      <div class="content">
        ${n(e.summary)}
        ${r(e.experience)}
        ${a(e.education)}
      </div>
    </main>
  `}var c=document.querySelector(`#app`);if(!c)throw Error(`Elemento #app não encontrado.`);c.innerHTML=s(e);